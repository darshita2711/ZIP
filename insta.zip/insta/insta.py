import instaloader
bot = instaloader.Instaloader()
 
ig = instaloader.Instaloader()

 
print("Plz provide the Instagram ID: ")
profile_name = str(input())
print("Provided Instagram ID: ", profile_name)
ig.download_profile(profile_name , profile_pic_only=True)   
profile = instaloader.Profile.from_username(bot.context, profile_name)

print("Full Name: ",profile.full_name)
print("Username: ", profile.username)
print("User ID: ", profile.userid)
print("Number of Posts:", profile.mediacount)
print("Followers:", profile.followers)
print("Followees: ", profile.followees)
print("Bio: ", profile.biography)
print("External URL: ",profile.external_url)
print("Blocked Anyone: ",profile.has_blocked_viewer)
print("Posts: ",profile.get_posts())