create database task1;
use task1;
create table Employee(Empid int primary key,EmpName varchar(255),Department varchar(255),ContactNo bigint,EmailId varchar(255),EmpHeadId varchar(255));
alter table Employee add foreign key (Department) references EmpDept(DeptId);
select * from Employee;
create table EmpSalary(Empid int,Salary varchar(255),IsPermanent varchar(255),foreign key(Empid) references Employee(Empid));
select * from EmpSalary;
insert into EmpSalary(Empid,Salary,IsPermanent)values(101,2000,'yes'),(102,10000,'yes'),(103,5000,'NO'),(104,1900,'yes'),(105,2300,'yes');
select * from EmpDept;
create table EmpDept(DeptId varchar(255) primary key,DeptName varchar(255),Dept_off varchar(255),DeptHead int,foreign key(DeptHead) references Employee(Empid));
insert into EmpDept(DeptId,DeptName,Dept_off,DeptHead)values('E-101','HR','Monday',105),('E-102','Development','Tuesday',101),('E-103','Hous Keeping','Saturday',103),('E-104','Sales','Sunday',104),('E-105','Purchage','Tuesday',104);

create table Project(ProjectId varchar(255) primary key,Duration varchar (255));
insert into Project(ProjectId,Duration)values('p-1',23),('p-2',15),('p-3',45),('p-4',2),('p-5',30);
select * from Project;
create table Country(cid varchar(255) primary key,cname varchar(255));
insert into Country(cid,cname)values('c-1','India'),('c-2','USA'),('c-3','China'),('c-4','Pakistan'),('c-5','Russia');
select * from Country;
create table ClientTable(ClientId varchar(255) primary key,ClientName varchar(255),cid varchar(255),foreign key(cid) references Country(cid));
select * from ClientTable;
insert into ClientTable(ClientId,ClientName,cid) values('cl-1','ABC Group','c-1'),('cl-2','PQR','c-1'),('cl-3','XYZ','c-2'),('cl-4','tech altum','c-3'),('cl-5','mnp','c-5');

create table EmpProject(Empid int , foreign key(Empid) references Employee(Empid),ProjectId varchar(255),foreign key(ProjectId)references Project(ProjectId),ClientID varchar(255),foreign key(ClientID) references ClientTable(ClientID),StartYear varchar(255),EndYear varchar(255));
insert into EmpProject(Empid,ProjectId,ClientID,StartYear,EndYear)values(101,'p-1','cl-1',2010,2010),(102,'p-2','cl-2',2010,2012),(103,'p-1','cl-3',2013,null),(104,'p-4','cl-1',2014,2015),(105,'p-4','cl-5',2015,null);
select * from EmpProject;

