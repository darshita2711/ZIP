use shruti;

-- create table stud(id int auto_increment,name varchar(255),Enrollment_No varchar(255) NOT NULL,primary key(id));
create table studt(id int not null unique,name varchar(255),subject varchar(255) NOT NULL);
insert into studt(name,subject)values("darshita","python");
select * from studt;