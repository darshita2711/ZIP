#create database student;
use student;
