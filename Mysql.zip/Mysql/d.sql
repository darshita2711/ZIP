-- create table orders(PersonID int auto_increment primary key,LastName varchar(255),FirstName varchar(255),Age varchar(255));
-- select * from orders;

-- create table persons(PersonID int auto_increment primary key,LastName varchar(255),FirstName varchar(255),Age varchar(255));
-- CREATE TABLE Orders (
--     OrderID int NOT NULL,
--     OrderNumber int NOT NULL,
--     PersonID int,
--     PRIMARY KEY (OrderID),
--     FOREIGN KEY (PersonID) REFERENCES persons(PersonID)
-- );
-- select * from persons;
-- select * from orders;
-- insert into orders values(2,12346,1),(3,1257,2),(4,454151,3)
-- select persons.PersonID,persons.FirstName,persons.LastName,orders.OrderNumber from persons inner join orders on persons.PersonID=orders.PersonID;
-- select persons.PersonId,persons.FirstName from persons left join orders on orders.PersonID=persons.PersonID;

-- select orders.OrderNumber,orders.OrderID from orders right join persons on orders.PersonID=persons.PersonID;

select persons.PersonID,persons.FirstName,orders.OrderNumber from persons CROSS join orders on orders.PersonID=persons.PersonID;