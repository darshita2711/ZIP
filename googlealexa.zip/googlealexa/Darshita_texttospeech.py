
from gtts import gTTS


import os

mytext=input("Please Speak I Can't wait...!!")

language="en"

val=gTTS(text=mytext,lang=language,slow=False)

val.save("myfiles.mp3")
os.system("start myfiles.mp3")