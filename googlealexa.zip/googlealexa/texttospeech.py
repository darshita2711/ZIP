
from gtts import gTTS
from playsound import playsound
import os

mytext=input("Please Enter I Can't wait...!!")

language="en"

val=gTTS(text=mytext,lang=language,slow=False)

val.save("myfiles.mp3")
playsound("myfiles.mp3")
# os.system("start myfiles.mp3")