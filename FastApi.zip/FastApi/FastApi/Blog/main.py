from typing import Optional
from fastapi import FastAPI, HTTPException, Form
from pydantic import BaseModel
from pydantic.networks import HttpUrl
from sqlalchemy.util.langhelpers import symbol
from starlette.responses import RedirectResponse
from starlette.routing import Host
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from fastapi import Request
from fastapi import Depends
from database import SessionLocal, engine
import models
import json
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from urllib.request import urlopen

app = FastAPI()
models.Base.metadata.create_all(bind=engine)
templates = Jinja2Templates(directory="templates")


class Blog(BaseModel):
    title: str
    body: str
    publish: Optional[bool]


class User(BaseModel):
    name: str
    email: str
    password: str


class Login(BaseModel):
    username: str
    password: str


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.post("/register")
async def register(request: User, db: Session = Depends(get_db)):
    new_user = models.User(
        name=request.name, email=request.email, password=request.password)
    print(new_user,"pppp")
    try:
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        return new_user
    except:
        return {
            "code": "Error (Email Must be not Used before)",
            "message": "User not created"
        }


@app.get("/user_reg")
def user_reg(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/user_reg")
async def user_reg(request: Request, db: Session = Depends(get_db),name: str = Form(...), password: str = Form(...), email: str = Form(...)):
    print(name,password,email)
    new_user = models.User(
        name=name, email=email, password=password)
    print(new_user,"pppp")
    try:
        db.add(new_user)
        db.commit()
     
    except:
        return templates.TemplateResponse("index.html", {"request": request})
 
    return templates.TemplateResponse("login.html", {"request": request})



@app.post("/login")
def login(request: Login, db: Session = Depends(get_db)):
    print(request.password,"ioio")
    user = db.query(models.User).filter(
        models.User.email == request.username).first()
    password = db.query(models.User).filter(models.User.password==request.password).first()
  
    if not user:
        raise HTTPException(status_code=404, detail=f"invalid user or password")

    if not password:
        raise HTTPException(status_code=404, detail=f"invalid password")

    else:
        return {
            "code": "Success!!!!",
            "message": "User Login"
        }

@app.get("/user_login")
def user_login(request: Request):
      return templates.TemplateResponse("login.html", {"request": request})
   
@app.post("/user_login")
async def user_login(request: Request,db: Session = Depends(get_db),username: str = Form(...), password: str = Form(...)):
    user = db.query(models.User).filter(
        models.User.email == username).first()
    password = db.query(models.User).filter(models.User.password==password).first()
    # url = "https://asx.api.markitdigital.com/asx-research/1.0/companies/directory?page=0&itemsPerPage=25&order=ascending&orderBy=companyName&includeFilterOptions=false&recentListingsOnly=false"
    # response = urlopen(url)
    # data_json = json.loads(response.read())
    print("IIIIII")
    
    if not user:
        raise templates.TemplateResponse("index.html", {"request": request})
    if not password:
        raise templates.TemplateResponse("index.html", {"request": request})
    else:
      return templates.TemplateResponse("stocks.html", {"request": request})
   
@app.post("/home")
def home(request: Request,db: Session = Depends(get_db),username: str = Form(...)):
    user = db.query(models.User).filter(models.User.email == username).first()
    user_email=user.email
    user_name=user.name
    print("ppiiii",user.email)
    symbol=[]
    displayName=[]
    industry=[]
    dateListed=[]
    marketCap=[]
    xid=[]
    priceChangeFiveDayPercent=[]
    isRecentListing=[]
  
   
    url = "https://asx.api.markitdigital.com/asx-research/1.0/companies/directory?page=0&itemsPerPage=25&order=ascending&orderBy=companyName&includeFilterOptions=false&recentListingsOnly=false"
    response = urlopen(url)
    data_json = json.loads(response.read())
    stock_datas=data_json
    stock_datas=stock_datas['data']['items']
  
    
    for stock_data in stock_datas:
        symbol.append(stock_data["symbol"])
        displayName.append(stock_data["displayName"])
        industry.append(stock_data["industry"])
        dateListed.append(stock_data.get("dateListed"))
        marketCap.append(stock_data["marketCap"])
        xid.append(stock_data["xid"])                               
        priceChangeFiveDayPercent.append(stock_data.get("priceChangeFiveDayPercent"))
        isRecentListing.append(stock_data["isRecentListing"])

    # data_dict = {"symbol":symbol,
    #         "displayName":displayName,
    #         "industry":industry,
    #         "dateListed":dateListed,
    #         "marketCap":marketCap,
    #         "xid":xid,
    #         "priceChangeFiveDayPercent":priceChangeFiveDayPercent,
    #         "isRecentListing":isRecentListing,
    #     }

  
    return templates.TemplateResponse("stocks.html", {"request": request,"stock_datas":stock_datas,"user":user_email,"user_name":user_name})

@app.get("/")
async def root():
    return RedirectResponse("/user_login")
    url = "https://asx.api.markitdigital.com/asx-research/1.0/companies/directory?page=0&itemsPerPage=25&order=ascending&orderBy=companyName&includeFilterOptions=false&recentListingsOnly=false"
    response = urlopen(url)
    data_json = json.loads(response.read())
    print(data_json)
    return data_json


@app.get("/data")
def data():
    return{"data": {"name": "Darshita Chavda"}}


@app.get("/blog/{id}")
def blog(id: int):
    return{"data": id}


@app.get("/blog/{id}/comments")
def comments(id):
    return{"data": {'1', '2'}}


@app.post("/blog")
def create_blog(request: Blog):
    return{"data": "created new blog"}


# if __name__=="__main__":
#     uvicorn.run(app,host="127.0.0.1",port='9000')
