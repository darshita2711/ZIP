# from sqlalchemy import create_engine,Column
from sqlalchemy import Boolean, Column, ForeignKey, Numeric, Integer, String
from sqlalchemy.orm import relationship
from sqlalchemy.sql.sqltypes import DateTime
from database import Base
# import datetime as _dt

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name=Column(String)
    email = Column(String, unique=True, index=True)
    password=Column(String)


    # items = sessionmaker.relationship("Item", back_populates="owner")

class Stock(Base):
    __tablename__ = "stocks"

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String, unique=True, index=True)
    price = Column(Numeric(10, 2))
    forward_pe = Column(Numeric(10, 2))
    forward_eps = Column(Numeric(10, 2))
    dividend_yield = Column(Numeric(10, 2))
    ma50 = Column(Numeric(10, 2))
    ma200 = Column(Numeric(10, 2))

class Stock_all(Base):
    __tablename__ = "stocks_all"

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String)
    displayName = Column(String)
    industry = Column(String)
    dateListed = Column(DateTime)
    marketCap = Column(Integer)
    xid = Column(Integer)
    priceChangeFiveDayPercent = Column(Integer)
    isRecentListing = Column(Boolean)